<?php
$koneksi = new mysqli ("localhost","root","","septian_saputra_311810265");
?>

<!-- end -->