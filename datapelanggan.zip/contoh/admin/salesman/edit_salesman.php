<?php

    if(isset($_GET['kode'])){
        $sql_cek = "SELECT * FROM salesman WHERE id_salesman='".$_GET['kode']."'";
        $query_cek = mysqli_query($koneksi, $sql_cek);
        $data_cek = mysqli_fetch_array($query_cek,MYSQLI_BOTH);
    }
?>

<div class="card card-success">
    <div class="card-header">
        <h3 class="card-title">
            <i class="fa fa-edit"></i> Ubah Data</h3>
    </div>
    <form action="" method="post" enctype="multipart/form-data">
        <div class="card-body">

            <input type='hidden' class="form-control" name="id_salesman" value="<?php echo $data_cek['id_salesman']; ?>"
             readonly/>

            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Id Salesman</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" id="id_salesman" name="id_salesman" value="<?php echo $data_cek['id_salesman']; ?>"
                    />
                </div>
            </div>

            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Nama Salesman</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" id="nama_salesman" name="nama_salesman" value="<?php echo $data_cek['nama_salesman']; ?>"
                    />
                </div>
            </div>

            <div class="form-group row">
                <label class="col-sm-2 col-form-label">No HP</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" id="nohp_sales" name="nohp_sales" value="<?php echo $data_cek['nohp_sales']; ?>"
                    />
                </div>
            </div>

        </div>
        <div class="card-footer">
            <input type="submit" name="Ubah" value="Simpan" class="btn btn-success">
            <a href="?page=data-pengguna" title="Kembali" class="btn btn-secondary">Batal</a>
        </div>
    </form>
</div>



<?php

    if (isset ($_POST['Ubah'])){
    $sql_ubah = "UPDATE salesman SET
        nama_salesman='".$_POST['nama_salesman']."',
        nohp_sales='".$_POST['nohp_sales']."'
        WHERE id_salesman='".$_POST['id_salesman']."'";


    $query_ubah = mysqli_query($koneksi, $sql_ubah);
    mysqli_close($koneksi);

    if ($query_ubah) {
        echo "<script>
      Swal.fire({title: 'Ubah Data Berhasil',text: '',icon: 'success',confirmButtonText: 'OK'
      }).then((result) => {if (result.value)
        {window.location = 'index.php?page=data-salesman';
        }
      })</script>";
      }else{
      echo "<script>
      Swal.fire({title: 'Ubah Data Gagal',text: '',icon: 'error',confirmButtonText: 'OK'
      }).then((result) => {if (result.value)
        {window.location = 'index.php?page=data-salesman';
        }
      })</script>";
    }}
?>

<script type="text/javascript">
    function change()
    {
    var x = document.getElementById('pass').type;

    if (x == 'password')
    {
        document.getElementById('pass').type = 'text';
        document.getElementById('mybutton').innerHTML;
    }
    else
    {
        document.getElementById('pass').type = 'password';
        document.getElementById('mybutton').innerHTML;
    }
    }
</script>