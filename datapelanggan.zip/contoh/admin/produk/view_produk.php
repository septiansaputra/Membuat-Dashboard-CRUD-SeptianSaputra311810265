<?php

    if(isset($_GET['kode'])){
        $sql_cek = "SELECT * from produk WHERE id_produk='".$_GET['kode']."'";
        $query_cek = mysqli_query($koneksi, $sql_cek);
        $data_cek = mysqli_fetch_array($query_cek,MYSQLI_BOTH);
    }
?>
<div class="row">

	<div class="col-md-8">
		<div class="card card-info">
			<div class="card-header">
				<h3 class="card-title">Detail produk</h3>

				<div class="card-tools">
				</div>
			</div>
			<div class="card-body p-0">
				<table class="table">
					<tbody>
						<tr>
							<td style="width: 150px">
								<b>Id Produk</b>
							</td>
							<td>:
								<?php echo $data_cek['id_produk']; ?>
							</td>
						</tr>
						<tr>
							<td style="width: 150px">
								<b>Nama Produk</b>
							</td>
							<td>:
								<?php echo $data_cek['nama_produk']; ?>
							</td>
						</tr>
						<tr>
							<td style="width: 150px">
								<b>Harga</b>
							</td>
							<td>:
								<?php echo $data_cek['harga_produk']; ?>
							</td>
						</tr>
						<tr>
							<td style="width: 150px">
								<b>Kemasan</b>
							</td>
							<td>:
								<?php echo $data_cek['kemasan_produk']; ?>
							</td>
						</tr>

					</tbody>
				</table>
				<div class="card-footer">
					<a href="?page=data-produk" class="btn btn-warning">Kembali</a>

					<a href="./report/cetak-pegawai.php?nip=<?php echo $data_cek['nip']; ?>" target=" _blank"
					 title="Cetak Data Pegawai" class="btn btn-primary">Print</a>
				</div>
			</div>
		</div>
	</div>

</div>